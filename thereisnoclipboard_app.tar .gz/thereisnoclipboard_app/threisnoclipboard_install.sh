#!/bin/bash
mv thereisnoclipboard_autostart.desktop $HOME/.config/autostart
sudo mv thereisnoclipboard  /usr/bin 
sudo mv thereisnoclipboard_install.sh /usr/bin